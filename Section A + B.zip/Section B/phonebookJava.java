import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;

public class phonebookJava {
    public static void main(String[] args) {
        JFrame frame = new JFrame("Phone Book");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(500, 400);
        frame.setLayout(new CardLayout());
        ArrayList<String> namesArray = new ArrayList<>();
        ArrayList<String> contactNumbers = new ArrayList<>();

        namesArray.add("Maria Hull");
        namesArray.add("Steve Benn");
        namesArray.add("Jack Conway");
        namesArray.add("Carol King");
        namesArray.add("Emma Dillon");
        namesArray.add("Keith David");
        namesArray.add("Harry Ondo");
        namesArray.add("Jack Conway");
        namesArray.add("Valentino Cantu");
        namesArray.add("Jovany Hopper");
        namesArray.add("Max Ivon");
        namesArray.add("Kennedy Coll");
        namesArray.add("Deacon Gales");
        namesArray.add("Xavier Ward");
        namesArray.add("Emily Sampson");
        namesArray.add("Bill Jackson");
        namesArray.add("Lilly Cyan");
        namesArray.add("Fabian Hurst");
        namesArray.add("Alexander Rivers");
        namesArray.add("Quinn Nelson");
        namesArray.add("Mata Prince");
        namesArray.add("Isaac Hoover");
        namesArray.add("Christian Downs");
        namesArray.add("Luciana Duffy");
        namesArray.add("Tessa Kidd");
        namesArray.add("Gill Vasquez");
        namesArray.add("Zachary Rose");

        contactNumbers.add("0834375567");
        contactNumbers.add("0819867509");
        contactNumbers.add("0818643228");
        contactNumbers.add("0850756489");
        contactNumbers.add("0812449767");
        contactNumbers.add("0850831234");
        contactNumbers.add("0812208434");
        contactNumbers.add("0850016473");
        contactNumbers.add("0819811920");
        contactNumbers.add("0818648853");
        contactNumbers.add("0851200434");
        contactNumbers.add("0812088856");
        contactNumbers.add("0854314673");
        contactNumbers.add("0819867520");
        contactNumbers.add("0818611228");
        contactNumbers.add("0851016489");
        contactNumbers.add("0812439487");
        contactNumbers.add("0852224237");
        contactNumbers.add("0819249509");
        contactNumbers.add("0818679228");
        contactNumbers.add("0851116489");
        contactNumbers.add("0812870767");
        contactNumbers.add("0851375567");
        contactNumbers.add("0819876509");
        contactNumbers.add("0818632918");
        contactNumbers.add("0850714829");
        contactNumbers.add("0816994382");

        //--------------------Front Panel--------------------------//
        JPanel frontPanel = new JPanel(new GridBagLayout());
        frontPanel.setBackground(new Color(0xf7f7f7));
        GridBagConstraints gbc = new GridBagConstraints();

        ImageIcon imageIcon = new ImageIcon("C:\\Users\\nanas\\OneDrive\\Desktop\\Group Project\\Phone Book\\logo.jpeg");
        Image scaledImage = imageIcon.getImage().getScaledInstance(100, 100, Image.SCALE_SMOOTH);
        ImageIcon scaledIcon = new ImageIcon(scaledImage);
        JLabel imageLabel = new JLabel(scaledIcon);
        gbc.gridy = 0;
        gbc.gridx = 0;
        gbc.insets = new Insets(20, 0, 20, 0);
        frontPanel.add(imageLabel, gbc);

        JLabel firstLbl = new JLabel("Phonebook");
        firstLbl.setFont(new Font("Cambria", Font.BOLD, 30));
        gbc.gridy = 1;
        gbc.gridx = 0;
        gbc.insets = new Insets(0, 0, 20, 0);
        frontPanel.add(firstLbl, gbc);

        JButton enterBtn = new JButton("Enter");
        gbc.gridy = 2;
        gbc.gridx = 0;
        frontPanel.add(enterBtn, gbc);
        //--------------------Front Panel--------------------------//


        //--------------------Main Panel---------------------------//
        JPanel mainPanel = new JPanel(new GridBagLayout());
        gbc.insets = new Insets(10, 10, 10, 10);

        JLabel header1 = new JLabel("Contacts");
        header1.setFont(new Font("Cambria", Font.BOLD, 18));
        gbc.gridy = 0;
        gbc.gridx = 0;
        gbc.anchor = GridBagConstraints.NORTHWEST;
        mainPanel.add(header1, gbc);

        JButton plusBtn = new JButton("+");
        gbc.gridx = 2;
        gbc.anchor = GridBagConstraints.NORTHEAST;
        mainPanel.add(plusBtn, gbc);

        JTextField searchBar = new JTextField(30);
        gbc.gridy = 1;
        gbc.gridx = 0;
        gbc.gridwidth = 3;
        gbc.anchor = GridBagConstraints.CENTER;
        mainPanel.add(searchBar, gbc);

        JLabel aboveLbl1 = new JLabel("Names");
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.anchor = GridBagConstraints.WEST;
        mainPanel.add(aboveLbl1, gbc);
        JList<String> List1 = new JList<>(namesArray.toArray(new String[0]));

        List1.setBackground(Color.WHITE);

        JScrollPane scrollP1 = new JScrollPane(List1);
        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.weighty = 0.5;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.WEST;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        mainPanel.add(scrollP1, gbc);

        JLabel aboveLbl2 = new JLabel("Phone numbers");
        gbc.gridx = 2;
        gbc.gridy = 2;
        gbc.anchor = GridBagConstraints.EAST;
        mainPanel.add(aboveLbl2, gbc);

        JList<String> List2 = new JList<>(contactNumbers.toArray(new String[0]));
        List2.setBackground(Color.WHITE);

        JScrollPane scrollP2 = new JScrollPane(List2);
        gbc.gridx = 2;
        gbc.gridy = 3;
        gbc.weighty = 0.5;
        gbc.gridwidth = 1;
        gbc.anchor = GridBagConstraints.EAST;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        mainPanel.add(scrollP2, gbc);

        JButton sortBtn = new JButton("Sort");
        gbc.gridy = 4;
        gbc.gridx = 0;
        gbc.gridwidth = 1;
        mainPanel.add(sortBtn, gbc);

        JButton infoBtn = new JButton("Info");
        gbc.gridx = 1;
        gbc.gridwidth = 1;
        mainPanel.add(infoBtn, gbc);

        JButton searchBtn = new JButton("Search");
        gbc.gridx = 2;
        gbc.gridwidth = 1;
        mainPanel.add(searchBtn, gbc);
        //--------------------Main Panel---------------------------//

        //--------------------Add Contact Panel--------------------//
        JPanel addContact = new JPanel(new GridBagLayout());
        GridBagConstraints gbc1 = new GridBagConstraints();
        gbc1.insets = new Insets(10, 10, 10, 10);

        JLabel header2 = new JLabel("Add new contact");
        header2.setFont(new Font("Cambria", Font.BOLD, 20));
        gbc1.gridy = 0;
        gbc1.gridx = 0;
        gbc1.gridwidth = 2;
        gbc1.anchor = GridBagConstraints.NORTHWEST;
        addContact.add(header2, gbc1);

        JLabel nameLbl = new JLabel("Name: ");
        gbc1.gridy = 1;
        gbc1.gridx = 0;
        gbc1.gridwidth = 1;
        addContact.add(nameLbl, gbc1);

        JTextField nameTextField = new JTextField(20);
        gbc1.gridx = 1;
        addContact.add(nameTextField, gbc1);

        JLabel numberLbl = new JLabel("Phone number: ");
        gbc1.gridy = 2;
        gbc1.gridx = 0;
        addContact.add(numberLbl, gbc1);

        JTextField numberTextField = new JTextField(20);
        gbc1.gridx = 1;
        addContact.add(numberTextField, gbc1);

        JButton addBtn = new JButton("Add");
        gbc1.gridy = 3;
        gbc1.gridx = 0;
        gbc1.gridwidth = 1;
        gbc1.anchor = GridBagConstraints.WEST;
        addContact.add(addBtn, gbc1);

        JButton doneBtn = new JButton("Done");
        gbc1.gridx = 1;
        gbc1.anchor = GridBagConstraints.EAST;
        gbc1.fill = GridBagConstraints.NONE;
        addContact.add(doneBtn, gbc1);
        //--------------------Add Contact Panel--------------------//


        //--------------------Contact Information Panel------------//
        JPanel contactInfo = new JPanel(new GridBagLayout());

        JLabel header3 = new JLabel("Contact Information");
        header3.setFont(new Font("Cambria", Font.BOLD, 20));
        gbc1.gridy = 0;
        gbc1.gridx = 0;
        gbc1.gridwidth = 2;
        gbc1.anchor = GridBagConstraints.NORTHWEST;
        contactInfo.add(header3, gbc1);

        JLabel contactName = new JLabel("Name: ");
        gbc1.gridy = 1;
        gbc1.gridx = 0;
        gbc1.gridwidth = 1;
        contactInfo.add(contactName, gbc1);

        JLabel contactNumber = new JLabel("Phone number: ");
        gbc1.gridy = 2;
        gbc1.gridx = 0;
        gbc1.gridwidth = 1;
        contactInfo.add(contactNumber, gbc1);

        JButton updateBtn = new JButton("Update");
        gbc1.gridy = 3;
        gbc1.gridx = 0;
        gbc1.gridwidth = 1;
        contactInfo.add(updateBtn, gbc1);

        JButton deleteBtn = new JButton("Delete");
        gbc1.gridy = 3;
        gbc1.gridx = 2;
        gbc1.gridwidth = 1;
        contactInfo.add(deleteBtn, gbc1);

        JButton backBtn = new JButton("Back to Main");
        gbc1.gridy = 4;
        gbc1.gridx = 1;
        gbc1.anchor = GridBagConstraints.SOUTH;
        gbc1.fill = GridBagConstraints.HORIZONTAL;
        contactInfo.add(backBtn, gbc1);
        //--------------------Contact Information Panel------------//


        //--------------------Update Contact Panel-----------------//
        JPanel updateContact = new JPanel(new GridBagLayout());

        JLabel header4 = new JLabel("Update contact");
        header4.setFont(new Font("Cambria", Font.BOLD, 20));
        gbc1.gridy = 0;
        gbc1.gridx = 0;
        gbc1.gridwidth = 2;
        gbc1.anchor = GridBagConstraints.NORTHWEST;
        updateContact.add(header4, gbc1);

        JLabel oldNameLbl = new JLabel("Current name: ");
        gbc1.gridy = 1;
        gbc1.gridx = 0;
        gbc1.gridwidth = 1;
        updateContact.add(oldNameLbl, gbc1);

        JLabel oldNumberLbl = new JLabel("Current phone number: ");
        gbc1.gridy = 2;
        gbc1.gridx = 0;
        gbc1.gridwidth = 1;
        updateContact.add(oldNumberLbl, gbc1);

        JLabel newNameLbl = new JLabel("New name: ");
        gbc1.gridy = 3;
        gbc1.gridx = 0;
        gbc1.gridwidth = 1;
        updateContact.add(newNameLbl, gbc1);
        JTextField newNameField = new JTextField(20);
        gbc1.gridx = 1;
        updateContact.add(newNameField, gbc1);

        JLabel newNumberLbl = new JLabel("New phone number: ");
        gbc1.gridy = 4;
        gbc1.gridx = 0;
        gbc1.gridwidth = 1;
        updateContact.add(newNumberLbl, gbc1);
        JTextField newNumberField = new JTextField(20);
        gbc1.gridx = 1;
        updateContact.add(newNumberField, gbc1);

        JButton confirmBtn = new JButton("Confirm");
        gbc1.gridy = 5;
        gbc1.gridx = 0;
        gbc1.gridwidth = 1;
        gbc1.anchor = GridBagConstraints.SOUTH;
        updateContact.add(confirmBtn, gbc1);


        JButton backToMainBtn = new JButton("Back");
        gbc1.gridx = 1;
        updateContact.add(backToMainBtn, gbc1);
        //--------------------Update Contact Panel-----------------//


        //---------------------Found Contact Panel------------------//
        JPanel foundContact = new JPanel(new GridBagLayout());

        JButton backBtn2 = new JButton("Back to Main");
        gbc1.gridy = 2;
        gbc1.anchor = GridBagConstraints.CENTER;
        gbc1.fill = GridBagConstraints.NONE;
        foundContact.add(backBtn2, gbc1);
        //---------------------Found Contact Panel------------------//

        enterBtn.addActionListener(e -> switchPanel(frame, "Main Module"));
        plusBtn.addActionListener(e -> switchPanel(frame, "Add Contact Option"));
        doneBtn.addActionListener(e -> switchPanel(frame, "Main Module"));
        infoBtn.addActionListener(e -> switchPanel(frame, "View Contact Information"));
        backToMainBtn.addActionListener(e -> switchPanel(frame, "Main Module"));
        backBtn.addActionListener(e -> switchPanel(frame, "Main Module"));
        backBtn2.addActionListener(e -> switchPanel(frame, "Main Module"));

        addBtn.addActionListener(e -> {
            String name = nameTextField.getText();
            String number = numberTextField.getText();
            namesArray.add(name);
            contactNumbers.add(number);
            nameTextField.setText("");
            numberTextField.setText("");

            List1.setListData(namesArray.toArray(new String[0]));
            List2.setListData(contactNumbers.toArray(new String[0]));

            switchPanel(frame, "Main Panel");
        });

        searchBtn.addActionListener(e -> {
            String searchItem = searchBar.getText().trim();
            foundContact.removeAll();

            boolean found = false;
            int index = -1;
            for (int i = 0; i < namesArray.size(); i++) {
                String name = namesArray.get(i);
                String[] parts = name.split(" ");
                if (parts.length > 1 && (parts[0].equals(searchItem) || parts[1].equals(searchItem))) {
                    found = true;
                    index = i;
                    break;
                }
            }

            if (found || contactNumbers.contains(searchItem)) {
                if (index != -1) {
                    JLabel result = new JLabel("<html> Name: " + namesArray.get(index) +
                            "<br> Number: " + contactNumbers.get(index) + "</html>");
                    gbc1.gridy = 1;
                    foundContact.add(result, gbc1);
                } else {
                    JLabel noResult = new JLabel("Contact not found.");
                    gbc1.gridy = 1;
                    foundContact.add(noResult, gbc1);
                }
            } else {
                JLabel noResult = new JLabel("Contact not found.");
                gbc1.gridy = 1;
                foundContact.add(noResult, gbc1);
            }

            foundContact.revalidate();
            foundContact.repaint();
            gbc1.gridy = 2;
            foundContact.add(backBtn2, gbc1);
            switchPanel(frame, "View Found Contact");
        });

        sortBtn.addActionListener(e -> {
            ArrayList<String[]> combinedList = new ArrayList<>();
            for (int i = 0; i < namesArray.size(); i++) {
                combinedList.add(new String[]{namesArray.get(i), contactNumbers.get(i)});
            }
            combinedList.sort((pair1, pair2) -> pair1[0].compareTo(pair2[0]));
            namesArray.clear();
            contactNumbers.clear();
            for (String[] pair : combinedList) {
                namesArray.add(pair[0]);
                contactNumbers.add(pair[1]);
            }
            List1.setListData(namesArray.toArray(new String[0]));
            List2.setListData(contactNumbers.toArray(new String[0]));
        });

        deleteBtn.addActionListener(e -> {
            String name = List1.getSelectedValue();
            if (name != null) {
                int index = namesArray.indexOf(name);
                namesArray.remove(index);
                contactNumbers.remove(index);
                List1.setListData(namesArray.toArray(new String[0]));
                List2.setListData(contactNumbers.toArray(new String[0]));
                JOptionPane.showMessageDialog(frame, "Contact Deleted successfully!");
            }
        });

        updateBtn.addActionListener(e -> {
            String oldName = List1.getSelectedValue();
            if (oldName != null) {
                int index = namesArray.indexOf(oldName);
                oldNameLbl.setText("Name: " + namesArray.get(index));
                oldNumberLbl.setText("Phone Number: " + contactNumbers.get(index));
            }
            switchPanel(frame, "Update Option");
        });

        confirmBtn.addActionListener(e -> {
            String oldName = List1.getSelectedValue();
            String newName = newNameField.getText();
            String newNumber = newNumberField.getText();
            int index = namesArray.indexOf(oldName);
            if (index != -1) {
                namesArray.set(index, newName);
                contactNumbers.set(index, newNumber);
                List1.setListData(namesArray.toArray(new String[0]));
                List2.setListData(contactNumbers.toArray(new String[0]));
            } else {
                JOptionPane.showMessageDialog(frame, "Press Back to go to Main Panel");
            }
            newNameField.setText("");
            newNumberField.setText("");
        });

        backToMainBtn.addActionListener(e -> switchPanel(frame,"Main Module"));

        infoBtn.addActionListener(e -> {
            String selectedName = List1.getSelectedValue();
            if (selectedName != null) {
                int index = namesArray.indexOf(selectedName);
                contactName.setText("Name: " + namesArray.get(index));
                contactNumber.setText("Phone Number: " + contactNumbers.get(index));
                switchPanel(frame, "View Contact Information");
            }
        });

        frame.add(frontPanel, "Front Cover");
        frame.add(mainPanel, "Main Module");
        frame.add(addContact, "Add Contact Option");
        frame.add(contactInfo, "View Contact Information");
        frame.add(updateContact, "Update Option");
        frame.add(foundContact, "View Found Contact");
        frame.setVisible(true);
    }

    private static void switchPanel(JFrame frame, String panelName) {
        CardLayout clay = (CardLayout) frame.getContentPane().getLayout();
        clay.show(frame.getContentPane(), panelName);
    }
}